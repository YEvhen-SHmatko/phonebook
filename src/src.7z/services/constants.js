import shortid from 'shortid';

export const ALL_ID = {
  nameId: shortid.generate(),
  numberId: shortid.generate(),
  finedId: shortid.generate(),
};
export const q = null;
